Figure 4B:
Homology models of ENST00000389093, ENST00000561609 and ENST00000568883. The homology models were built using Schrodinger Suite software (Schr�dinger/2019-3, LLC, New York, NY). The input is the amino acid sequence of these transcripts.
Compared to PKM2 (yellow), the catalytic ADP binding site in ENST000000389093 (green) structure is missing. The missing part of ENST000000389093 is colored in purple in PKM2 and the key amino acid residues for contacting ADP is labeled out.  
Compared to PKM1 (yellow), ENST000000561609 (green) is missing part of the amino acid residues that are constitutes part of the C-C binding interface. The missing part of ENST000000561609 is colored in purple in PKM1. 
Compared to PKM1(yellow), ENST00000568883 is missing large of the structure in A and B domain, and the N-terminal is completely lost. The missing part of ENST00000568883 is colored in purple in PKM1. 
