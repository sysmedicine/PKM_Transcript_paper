# Source Data

We collected the source data for each figure, table and supplementary material in an independent file named as the order of this figure or table, e.g. Figure_1A.\
Each folder includes a "Output" folder which gives the result generated from this source data based on main code.

### Note: UNZIP ALL FILES as separate folder





