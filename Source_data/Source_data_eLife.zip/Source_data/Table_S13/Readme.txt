This folder includes amino acid sequence for each transcript.
