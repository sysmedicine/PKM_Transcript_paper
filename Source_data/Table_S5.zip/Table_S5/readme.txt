In each folder named as transcript Ensembl ID
Up_GoTerm_p_matrix.txt: P values of go terms enriched with up differentially expressed genes; NA denotes that this pathway is not significantly enriched at certain significance level.
Down_GoTerm_p_matrix.txt: P values of go terms enriched with down differentially expressed genes; NA denotes that this pathway is not significantly enriched at certain significance level.
GoTerm_id.txt: The corresponding go term id for each go term in the file "Up_GoTerm_p_matrix.txt" and "Down_GoTerm_p_matrix.txt"