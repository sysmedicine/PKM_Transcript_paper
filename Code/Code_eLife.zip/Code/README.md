# Codes

This file includes the code for each figure, table and supplementary material. All the code is performed by R language (Version 3.5.1). The expected output have been saved in an independent folder named as "Output" in the "Source_data" folder.
The expected run time for the code of each figure or table is less than 10 minutes.

Each R file (code file) includes the description of its function.


